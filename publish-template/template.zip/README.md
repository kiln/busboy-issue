This template is ideal for visualising survey responses and other data where each row represents a discrete entity such as a person. It lets you animate dots into different views, including groups, bars, and – for geographic data – a world map. It also allows you to compare different metrics in a grid view.

## Data requirements

The survey template is ideal for datasets up to around 10,000 rows. Larger datasets will work, but perform more slowly.

You'll need a CSV or Excel file with a row for each person or entity that you want to visualise.

In the case of survey data, your CSV file should have:

– a row for each person who took the survey
- a column for each question in the survey or other piece of information about the respondent

## Getting started

First, from your projects page, create a new Survey visualisation. Open the Data view, go to the “Data” sheet and import your data to overwrite the current sheet. Then, on the right, update the column settings:

- Set “Categorical columns” to point to any columns with _categorical_ answers, i.e. text like "male"/"female" or "0-99"/"100-999"/"1000-9990". Type in the column numbers - e.g. `A-C`. These columns will appear in in the “Group by”, “Shade by” and “Compare” dropdown in the visualisation.
- Set “Continuous columns” to point to any columns with _continuous_ answers, i.e. raw numbers, such as income or weight. These columns will appear in the “Size by” dropdown in the visualisation.

If you switch back to the Preview view, you should now see your data in the survey.

## Change the text displayed

It's quite common that you want to change text shown in the visualisation - for example, you might have `y` and `n` as answers in your raw data, but want this to be displayed as `yes` or `no` in your visualisation.

To avoid editing the raw data (which may make it harder to update later), you can use the “Label overrides” sheet. Simply type the values you want to change (e.g. `y`) in the first column and the values you want to show (e.g. `yes`) in the second column. The visualisation should automatically update to show the new text.

## Change the ordering of groups

It's also quite common that you want to change the order of answers, which by default will display alphabetically. For example, you might prefer to show groups for `Yes`, `No`, and `Answer not supplied` in that order.

To do this, go to the “Natural order” data sheet, and fill in the heading of column A with the column name of the relevant question in the “Data” sheet. Underneath, type or paste in the answer values in the order that you'd like them displayed. Then, in the column settings panel, update “Order of answers” to point at column A.

You can repeat this for as many columns as necessary.

## Customise the popups

In the data bindings panel, find “Metadata” and add any columns that you want to include in popups. Then, in the settings panel, ensure “Show popups” is checked, and edit “Popup contents” to include the columns, with column names in `{{brackets}}`.

The “Popup contents” is HTML, so you can include formatting, e.g. `<strong>Name:</strong> {{Name}}`, or even images if you include image URL in your data sheet.

If this isn't working, check you're using the exact column names and that you haven't included spaces inside the brackets - so `{{Name}}` not `{{ Name }}`.

## Let users filter the data

You can allow users to filter your survey results within the visualisation - e.g. by year or another attribute.

To do this, in the data bindings panel, update the “Slider or menu” binding to point at the column you want to filter by.

Then, in the settings panel, choose “Control style” to specify the type of filter control you want - a button group, dropdown, or slider.

## Grouped question

Survey data often includes grouped questions – i.e. those in the form "What food do you like (pick up to three)". In this model, the data sheet would typically include a column for each possible answer with a yes or no answer. The template allows you to group these questions together to enable you to compare the frequency of the positive answers.

When grouping by such a question, the number of dots may increase, because each survey respondent may appear multiple times – one for each positive answer. Because of this it's not possible to shade by a grouped question.

To create a grouped question, use the “Answer Groups” sheet. Put in the question you want to create in the first column, the column header for each sub-question in the next column, the display name for the group in the following column, and finally the way a positive answer is seen – e.g. “y” or “1”.

## Display your data on a map

If you have country names in your data, you can display the data on a world map without doing much extra work. Just ensure that the “Geographic columns” binding points at the column with country names in it, and that your country names match the “Countries” sheet.

If your data has other geographic locations, such as city names, you'll need to do a bit more work! First, ensure that the “Geographic columns” binding points at the column with locations in it. Then replace the “Countries” sheet with your geographic locations - you'll need latitude, longitude and name columns.

To change the default position displayed on the map, you'll need to [create a Flourish story](https://flourish.studio/help/create-a-flourish-story/). Inside the story, click the map view, then zoom to the position you want to display: the slide will save the position. Publish the story to share it with your users.
